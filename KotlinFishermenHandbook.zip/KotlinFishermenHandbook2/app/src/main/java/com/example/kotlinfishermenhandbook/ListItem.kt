package com.example.kotlinfishermenhandbook

class ListItem (
    var image_id:Int,
    var titleText:String,
    var contentText:String
    )